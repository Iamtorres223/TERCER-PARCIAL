#ifndef LLANTA_H
#define LLANTA_H

#include <string>
#include <vector>
#include <fstream>
#include <sstream>

struct Llanta {
    int id;
    std::string marca, modelo, tipo;
    float precio;
    int stock;
};

extern int idGlobal;
extern std::vector<Llanta> inventario;

inline void cargarInventario(const std::string& archivo) {
    inventario.clear();
    std::ifstream f(archivo);
    std::string linea;
    while (getline(f, linea)) {
        std::stringstream ss(linea);
        Llanta l;
        std::string campo;
        getline(ss, campo, ','); l.id = std::stoi(campo);
        getline(ss, l.marca, ',');
        getline(ss, l.modelo, ',');
        getline(ss, l.tipo, ',');
        getline(ss, campo, ','); l.precio = std::stof(campo);
        getline(ss, campo, ','); l.stock = std::stoi(campo);
        inventario.push_back(l);
        if (l.id >= idGlobal) idGlobal = l.id + 1;
    }
}

inline void guardarInventario(const std::string& archivo) {
    std::ofstream f(archivo);
    for (auto& l : inventario) {
        f << l.id << "," << l.marca << "," << l.modelo << "," << l.tipo << ","
          << l.precio << "," << l.stock << "\n";
    }
}

#endif // LLANTA_H
