#include "mainwindow.h"
#include <QApplication>

int idGlobal = 1;
std::vector<Llanta> inventario;
std::unordered_map<QString, Usuario> usuarios;
Usuario usuarioActual = {"admin", "admin", "admin"}; // Para pruebas rápidas

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
