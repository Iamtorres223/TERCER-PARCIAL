#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QInputDialog>
#include <QDateTime>
#include <QFile>
#include <QTextStream>

extern std::vector<Llanta> inventario;
extern std::unordered_map<QString, Usuario> usuarios;
extern Usuario usuarioActual;
extern int idGlobal;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    cargarDatos();

    if (usuarioActual.rol != "admin") {
        ui->btnAgregar->hide();

    }
}

MainWindow::~MainWindow() {
    guardarDatos();
    delete ui;
}

void MainWindow::cargarDatos() {
    cargarInventario("inventario.csv");
    cargarUsuarios("usuarios.csv");
}

void MainWindow::guardarDatos() {
    guardarInventario("inventario.csv");
    guardarUsuarios("usuarios.csv");
}

void MainWindow::on_btnInventario_clicked() {
    QString datos;
    for (const auto& l : inventario) {
        datos += QString("ID: %1 | Marca: %2 | Modelo: %3 | Tipo: %4 | Precio: $%5 | Stock: %6\n")
                 .arg(l.id).arg(QString::fromStdString(l.marca))
                 .arg(QString::fromStdString(l.modelo)).arg(QString::fromStdString(l.tipo))
                 .arg(l.precio, 0, 'f', 2).arg(l.stock);
    }
    QMessageBox::information(this, "Inventario", datos.isEmpty() ? "Vacío." : datos);
}

void MainWindow::on_btnVender_clicked() {
    bool ok;
    int id = QInputDialog::getInt(this, "Vender", "ID de llanta:", 1, 1, 9999, 1, &ok);
    if (!ok) return;

    for (auto& l : inventario) {
        if (l.id == id) {
            int cantidad = QInputDialog::getInt(this, "Cantidad", "Cantidad:", 1, 1, l.stock, 1, &ok);
            if (ok) {
                l.stock -= cantidad;

                QFile file(QString("ticket_%1.txt")
                           .arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss")));
                if (file.open(QFile::WriteOnly | QFile::Text)) {
                    QTextStream out(&file);
                    out << "=== TICKET DE VENTA ===\n";
                    out << "Fecha: " << QDateTime::currentDateTime().toString() << "\n";
                    out << "Llanta: " << QString::fromStdString(l.marca) << " - " << QString::fromStdString(l.modelo) << "\n";
                    out << "Cantidad: " << cantidad << "\n";
                    out << "Total: $" << QString::number(l.precio * cantidad, 'f', 2) << "\n";
                    file.close();
                }

                QMessageBox::information(this, "Venta", "Venta realizada. Ticket generado.");
                return;
            }
        }
    }
    QMessageBox::warning(this, "Error", "Llanta no encontrada.");
}

void MainWindow::on_btnAgregar_clicked() {
    Llanta l;
    l.id = idGlobal++;
    l.marca = QInputDialog::getText(this, "Marca", "Marca:").toStdString();
    l.modelo = QInputDialog::getText(this, "Modelo", "Modelo:").toStdString();
    l.tipo = QInputDialog::getText(this, "Tipo", "Tipo:").toStdString();
    l.precio = QInputDialog::getDouble(this, "Precio", "Precio:", 0, 0);
    l.stock = QInputDialog::getInt(this, "Stock", "Cantidad en stock:", 0, 0);
    inventario.push_back(l);
    QMessageBox::information(this, "Agregado", "Llanta agregada.");
}

void MainWindow::on_btnRegistrar_clicked() {
    Usuario u;
    u.nombre = QInputDialog::getText(this, "Usuario", "Nombre:").toStdString();
    if (usuarios.count(QString::fromStdString(u.nombre))) {
        QMessageBox::warning(this, "Error", "Ya existe.");
        return;
    }
    u.contrasena = QInputDialog::getText(this, "Contraseña", "Contraseña:").toStdString();
    u.rol = QInputDialog::getText(this, "Rol", "Rol (admin o ventas):").toStdString();
    usuarios[QString::fromStdString(u.nombre)] = u;
    QMessageBox::information(this, "Registro", "Usuario registrado.");
}

void MainWindow::on_btnSalir_clicked() {
    guardarDatos();
    close();
}
