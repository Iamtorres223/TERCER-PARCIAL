#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <vector>
#include <unordered_map>
#include "llanta.h"
#include "usuario.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void cargarDatos();
    void guardarDatos();
    void mostrarInventario();

private slots:
    void on_btnInventario_clicked();
    void on_btnVender_clicked();
    void on_btnAgregar_clicked();
    void on_btnRegistrar_clicked();
    void on_btnSalir_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
