#ifndef USUARIO_H
#define USUARIO_H

#include <string>
#include <unordered_map>
#include <fstream>
#include <sstream>

struct Usuario {
    std::string nombre;
    std::string contrasena;
    std::string rol;
};

extern std::unordered_map<QString, Usuario> usuarios;
extern Usuario usuarioActual;

inline void cargarUsuarios(const std::string& archivo) {
    usuarios.clear();
    std::ifstream f(archivo);
    std::string linea;
    while (getline(f, linea)) {
        std::stringstream ss(linea);
        Usuario u;
        getline(ss, u.nombre, ',');
        getline(ss, u.contrasena, ',');
        getline(ss, u.rol, ',');
        usuarios[QString::fromStdString(u.nombre)] = u;
    }
}

inline void guardarUsuarios(const std::string& archivo) {
    std::ofstream f(archivo);
    for (auto& [k, u] : usuarios) {
        f << u.nombre << "," << u.contrasena << "," << u.rol << "\n";
    }
}

#endif // USUARIO_H
